<div class="clear"></div>
</div>

</div>
<?php wp_footer(); ?>
</body>
</html>