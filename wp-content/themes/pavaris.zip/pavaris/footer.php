<div class="clear"></div>
</div>
<footer id="footer" role="contentinfo">
<?php get_about(); ?>

</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>